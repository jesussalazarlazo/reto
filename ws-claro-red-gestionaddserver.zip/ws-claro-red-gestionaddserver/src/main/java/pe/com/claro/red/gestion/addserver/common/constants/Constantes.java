package pe.com.claro.red.gestion.addserver.common.constants;

public class Constantes {

  public static final String NOMBRERECURSO = "claro-red-gestionaddserver";
  public static final String PROPERTIESKEY = "claro.properties";
  public static final String PROPERTIESEXTERNOS = "application.properties";
  public static final String SEPARADOR = "-----------------------------------------------------------------------------";
  public static final String SALTO_LINEA = "\n";
  public static final String INICIO_SERVICE = "====== [Inicio] En Service {} ======";
  public static final String FIN_SERVICE = "====== [Fin] En Service {} ======";
  public static final String RECIBETRIPLETA = " RecibeTripletService ";
  public static final String CHAR_CORCHETE_IZQUIERDO = "[";
  public static final String CHAR_CORCHETE_DERECHO = "]";
  public static final String INICIO_ACTIVIDAD = "------- [INICIO ACTIVIDAD]: ";
  public static final String FIN_ACTIVIDAD = "------- [FIN ACTIVIDAD]: ";
  public static final String SEPARADOR_ACTIVIDAD = " ---------------------";
  public static final String INICIO_METODO = "[INICIO de metodo: %s]";
  public static final String FIN_METODO = "[FIN de metodo: %s]";
  public static final String PARAMETROSENTRADA = "Parametros de entrada:";
  public static final String PARAMETROSSALIDA = "Parametros de salida:";
  public static final String PARAMETROSHEADER = "Header Request:";
  public static final String PARAMETROSBODY = "Body Request:";
  public static final String RESPONSE = "Response:";
  public static final String ACTIVIDAD1 = "1. Obtener tripleta";
  public static final String ACTIVIDAD2 = "2. Validar parametros obligatorio";
  public static final String ACTIVIDAD3 = "3. Insertar registro en tabla intermedia";
  public static final String ACTIVIDAD4 = "4. Insertar registro en tabla de errores";
  public static final String ERROR = "[ERROR]:";
  public static final String TIEMPOTOTALPROCESO = "Tiempo TOTAL del proceso: %s ms";
  public static final String MILISEGUND = "milisegundos";
  public static final String ERROR_EXCEPTION = "Error Exception: ";
  public static final String FORMATOFECHACABECERA = "yyyy-MM-dd'T'HH:mm:ss'Z'";
  public static final String FORMATOFECHAIDTX = "yyMMddHHmmssSSS";
  public static final String FORMATOFECHAHORA = "yyyy/MM/dd HH:mm:ss";
  public static final String SLASH = "/";
  public static final String GUION = " - ";
  public static final String DOS_PUNTOS = ":";
  public static final String PUNTO_COMA = ";";
  public static final String PUNTO = ".";
  public static final String COMA = ",";
  public static final String TEXTO_VACIO = "";
  public static final String TEXTO_ESPACIO = " ";
  public static final int NUM_CERO = 0;
  public static final int NUM_UNO = 1;
  public static final String TEXTO_CERO = "0";
  public static final String NULL = "null";
  public static final String VALOR_PROPERTIES = "Valor de properties: ";
  public static final String VALOR = "Valor: ";
  public static final String MTRES = "-3";
  public static final String DOS = "2";
  public static final String UNO_STR = "1";
  public static final String MUNO = "1";

  public static final String IMSI = "IMSI";
  public static final String MSISDN = "MSISDN";
  public static final String DEVICEID = "deviceID";
  public static final String SP_OWNER = "OWNER: ";
  public static final String SP_PAQUETE = "PAQUETE: ";
  public static final String SP_PROCEDURE = "PROCEDURE: ";
  public static final String SP_NOMBREBD = "BASE DE DATOS: ";
  public static final String SP_USUARIO = "USUARIO: ";
  public static final String SP_JNDI = "JNDI: ";
  public static final String PARAMETRO_CALL = "call %s %s";
  public static final String SP_INPUT6 = "(?,?,?,?,?,?)";
  public static final String SP_INPUT7 = "(?,?,?,?,?,?,?)";

  public static final String SP_ERR_PI_IDTX = "PI_IDTX";
  public static final String SP_ERR_PI_PROCESO = "PI_PROCESO";
  public static final String SP_ERR_PI_COD = "PI_COD";
  public static final String SP_ERR_PI_DESC = "PI_DESCRIPCION";
  public static final String SP_ERR_PI_FECHA = "PI_FECHA";

  public static final String SP_INT_PI_FECHA = "PI_FECHA_REGISTRO";
  public static final String SP_INT_PI_IMSI = "PI_IMSI";
  public static final String SP_INT_PI_MSISDN = "PI_MSISDN";
  public static final String SP_INT_PI_IMEI = "PI_IMEI";

  public static final String PROCESANDO_SP = "Procesando SP ... ";

  public static final String ERROR_EJECUCION_SP = "Error en la ejecucion del SP: ";
  public static final String TIMEOUTEXCEPTION = "TIMEOUT";
  public static final String HIBERNATEJDBCEXCEPTION = "The application must supply JDBC connections";
  public static final String GENERICJDBCEXCEPTION = "org.hibernate.exception";
  public static final String PERSISTENCEEXCEPTION = "javax.persistence.PersistenceException";
  public static final String SQLSYNTAXERROREXCEPTION = "SQLSYNTAXERROREXCEPTION";
  public static final String CANNOT_GET_CONNECTION = "Cannot get connection: ";
  public static final String CODE = " [CODE]=";
  public static final String MSG = " [MSG]=";
  public static final String TRACE = " [TRACE]";
  public static final String VARIABLE_DB = "$bd";
  public static final String VARIABLE_SP = "$sp";
  public static final String VARIABLE_EX = "$ex";
  public static final String SQL_EXCEPTION = "ERROR SQLException: ";

  public static final String LOG_PARAM2 = "{} {}";
  public static final String LOG_PARAM3 = "{} {} {}";
  public static final String LOG_PARAM4 = "{} {} {} {}";

  public static final String NOMBREMETODO = "recibirTripleta";
  public static final String ID_TXT = "[idTx=%s]";
  public static final String METODOINICIO = "[Inicio Metodo:";
  public static final String APPLICATIONJSON = "application/json";
  public static final String ORACLEDRIVER = "oracle.jdbc.driver.OracleDriver";
  public static final String VALIDACIONCORRECTA = "Validacion correcta de parametros de entrada";

}
