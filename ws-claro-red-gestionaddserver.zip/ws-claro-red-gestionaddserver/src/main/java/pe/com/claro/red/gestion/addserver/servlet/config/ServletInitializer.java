package pe.com.claro.red.gestion.addserver.servlet.config;

import java.io.File;
import java.util.Properties;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

import pe.com.claro.red.gestion.addserver.ClaroRedGestionAddServerApp;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;

public class ServletInitializer extends SpringBootServletInitializer {

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
    return application.sources(ClaroRedGestionAddServerApp.class).properties(getProperties());
  }

  static Properties getProperties() {
    Properties props = new Properties();
    String pathClaroProp = System.getProperty(Constantes.PROPERTIESKEY) + Constantes.NOMBRERECURSO + File.separator
        + Constantes.PROPERTIESEXTERNOS;
    props.put("spring.config.location", "file:" + pathClaroProp);
    return props;
  }
}