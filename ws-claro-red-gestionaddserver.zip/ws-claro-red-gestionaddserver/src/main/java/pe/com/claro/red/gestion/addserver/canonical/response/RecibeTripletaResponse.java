package pe.com.claro.red.gestion.addserver.canonical.response;

import lombok.Data;

@Data
public class RecibeTripletaResponse {

  private RecibeTripletaResponseType tripletaResponse;

}
