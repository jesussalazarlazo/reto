package pe.com.claro.red.gestion.addserver.common.util;

import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import pe.com.claro.red.gestion.addserver.common.constants.Constantes;

public class ClaroUtil {

  private static final Logger log = LoggerFactory.getLogger(ClaroUtil.class);

  public static DateFormat getLocalFormat() {
    DateFormat dateFormat = new SimpleDateFormat(Constantes.FORMATOFECHACABECERA);
    dateFormat.setTimeZone(TimeZone.getDefault());
    return dateFormat;
  }

  public static String printPrettyJSONString(Object o) throws JsonProcessingException {
    return new ObjectMapper().setDateFormat(ClaroUtil.getLocalFormat())
        .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false).writerWithDefaultPrettyPrinter()
        .writeValueAsString(o);
  }

  public static String dateAString(Date fecha, String formato) {

    if (fecha != null) {
      SimpleDateFormat formatoDF = new SimpleDateFormat(formato, Locale.US);
      return formatoDF.format(fecha);
    } else {
      return null;
    }

  }

  public static Connection getConnection(String menTran, String jndi, int tiempoConexion)
      throws NamingException, SQLException {

    Connection result = null;

    try {

      Context initialContext = new InitialContext();
      DataSource datasource = (DataSource) initialContext.lookup(jndi);
      datasource.setLoginTimeout(tiempoConexion);
      result = datasource.getConnection();
    } catch (NamingException ex) {
      log.debug(menTran + Constantes.CANNOT_GET_CONNECTION, ex);
      throw new NamingException();
    } catch (SQLException ex) {
      log.debug(menTran + Constantes.SQL_EXCEPTION, ex);
      throw new SQLException();
    }
    return result;
  }

  public static void connectionClose(ResultSet kResultCursor, CallableStatement call, Connection connection,
      String msgTransaction) {
    try {
      if (null != kResultCursor) {
        kResultCursor.close();
        log.debug(msgTransaction + "Cursor cerrado: " + kResultCursor.isClosed());
      }

      if (null != call) {
        call.close();
        log.debug(msgTransaction + "CallableStatement cerrado: " + call.isClosed());
      }

      if (null != connection) {
        connection.close();
        log.debug(msgTransaction + "Connection cerrado: " + connection.isClosed());
      }
    } catch (SQLException e) {
      log.debug(msgTransaction + Constantes.SQL_EXCEPTION + e);
    }
  }
}
