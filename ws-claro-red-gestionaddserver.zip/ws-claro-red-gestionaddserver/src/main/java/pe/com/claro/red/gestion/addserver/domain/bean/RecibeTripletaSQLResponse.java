package pe.com.claro.red.gestion.addserver.domain.bean;

import lombok.Data;

@Data
public class RecibeTripletaSQLResponse {

  private String codRpta;
  private String msjRpta;

}
