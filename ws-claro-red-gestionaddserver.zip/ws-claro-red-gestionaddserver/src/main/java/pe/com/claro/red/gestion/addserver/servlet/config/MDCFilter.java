package pe.com.claro.red.gestion.addserver.servlet.config;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class MDCFilter extends OncePerRequestFilter {

  private static final String CORRELATION_ID_HEADER_NAME = "idTransaccion";

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
      throws ServletException, IOException {
    MDC.put("uniqueTrackingNumber", getCorrelationIdFromHeader(request));
    try {
      filterChain.doFilter(request, response);
    } finally {
      MDC.remove("uniqueTrackingNumber");
    }
  }

  private String getCorrelationIdFromHeader(final HttpServletRequest request) {
    String correlationId = request.getHeader(CORRELATION_ID_HEADER_NAME);
    correlationId = generateUniqueCorrelationId(correlationId);
    return correlationId;
  }

  private String generateUniqueCorrelationId(String correlationId) {
    return "[traId-App:" + correlationId + "]-[traId-API:" + UUID.randomUUID().toString() + "]";
  }
}