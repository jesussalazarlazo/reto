package pe.com.claro.red.gestion.addserver.domain.repository;
 
import pe.com.claro.red.gestion.addserver.canonical.request.RegistraProductoRequest;
import pe.com.claro.red.gestion.addserver.common.exceptions.DBException;

import pe.com.claro.red.gestion.addserver.domain.bean.RegistraProductoBeanResponse;

public interface RegistroProductoDao {

  
  public RegistraProductoBeanResponse registaProducto(String msgIdtx, RegistraProductoRequest request) 
		  throws DBException;
}
