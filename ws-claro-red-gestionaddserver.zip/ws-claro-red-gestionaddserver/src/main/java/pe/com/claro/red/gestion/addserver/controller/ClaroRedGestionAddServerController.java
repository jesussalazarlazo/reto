package pe.com.claro.red.gestion.addserver.controller;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import pe.com.claro.red.gestion.addserver.canonical.response.RecibeTripletaResponse;
import pe.com.claro.red.gestion.addserver.canonical.response.RecibeTripletaResponseType;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;
import pe.com.claro.red.gestion.addserver.common.util.ClaroUtil;
import pe.com.claro.red.gestion.addserver.domain.service.RecibeTripletaService;

@RestController
@RequestMapping
public class ClaroRedGestionAddServerController {

  private static final Logger logger = LoggerFactory.getLogger(ClaroRedGestionAddServerController.class);

  @Autowired
  private RecibeTripletaService recibeTripletaService;

  @GetMapping
  public RecibeTripletaResponse recibirTripleta(@RequestParam(value = Constantes.IMSI, required = false) String imsi,
      @RequestParam(value = Constantes.MSISDN, required = false) String msisdn,
      @RequestParam(value = Constantes.DEVICEID, required = false) String imei) {

    long tiempoInicio = System.currentTimeMillis();
    Date fechaSistema = new Date();

    String idTransaccion = ClaroUtil.dateAString(fechaSistema, Constantes.FORMATOFECHAIDTX);
    String fecha = ClaroUtil.dateAString(fechaSistema, Constantes.FORMATOFECHAHORA);
    Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().serializeNulls().create();

    String msjTx = String.format(Constantes.ID_TXT, idTransaccion);

    RecibeTripletaResponse response = new RecibeTripletaResponse();
    RecibeTripletaResponseType responseType = new RecibeTripletaResponseType();

    logger.info(Constantes.SEPARADOR);
    logger.info(Constantes.LOG_PARAM2, msjTx, String.format(Constantes.INICIO_METODO, Constantes.NOMBREMETODO));
    logger.info(Constantes.SEPARADOR);

    try {

      responseType = recibeTripletaService.recibirTripleta(msjTx, fecha, idTransaccion, imsi, msisdn, imei);
      response.setTripletaResponse(responseType);
      logger.info(Constantes.LOG_PARAM3, msjTx, Constantes.RESPONSE, gson.toJson(response));

    } catch (Exception e) {
      logger.error(msjTx, e);

    } finally {
      long tiempoProceso = System.currentTimeMillis() - tiempoInicio;
      logger.info(Constantes.LOG_PARAM2, msjTx, String.format(Constantes.TIEMPOTOTALPROCESO, tiempoProceso));
      logger.info(Constantes.SEPARADOR);
      logger.info(Constantes.LOG_PARAM2, msjTx, String.format(Constantes.FIN_METODO, Constantes.NOMBREMETODO));
      logger.info(Constantes.SEPARADOR);
    }
    return response;
  }

}