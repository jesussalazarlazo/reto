package pe.com.claro.red.gestion.addserver.common.exceptions;

public class IDFException extends BaseException {

  private static final long serialVersionUID = 1L;

  public IDFException(String msjError) {
    super(msjError);
  }

  public IDFException(String codError, String msjError) {
    super(codError, msjError);
  }

  public IDFException(String msjError, Exception objException) {
    super(msjError, objException);
  }
}
