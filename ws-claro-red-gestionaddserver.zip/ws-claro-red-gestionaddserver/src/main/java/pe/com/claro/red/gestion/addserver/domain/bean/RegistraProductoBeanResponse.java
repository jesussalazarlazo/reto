package pe.com.claro.red.gestion.addserver.domain.bean;

import java.util.List;

import lombok.Data;

@Data
public class RegistraProductoBeanResponse {

	  private String codigoRespuesta;
	    private String mensajeRespuesta;
	    private List<CursorOut> cursorOut;
	}

	@Data
	class CursorOut {
	    private String idProducto;
	    private String nombre;
	    private String fechaRegistro;
	}