package pe.com.claro.red.gestion.addserver.canonical.request;

import lombok.Data;

@Data
public class RecibeTripletaRequest {

  private RecibeTripletaRequestType tripletaRequest;

}
