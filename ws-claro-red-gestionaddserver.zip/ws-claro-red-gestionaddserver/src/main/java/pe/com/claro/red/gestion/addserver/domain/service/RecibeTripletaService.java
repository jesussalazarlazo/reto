package pe.com.claro.red.gestion.addserver.domain.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import pe.com.claro.red.gestion.addserver.canonical.request.RecibeTripletaRequestType;
import pe.com.claro.red.gestion.addserver.canonical.response.RecibeTripletaResponseType;
import pe.com.claro.red.gestion.addserver.canonical.response.ResponseBean;
import pe.com.claro.red.gestion.addserver.canonical.type.ResponseData;
import pe.com.claro.red.gestion.addserver.canonical.type.ResponseStatus;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;
import pe.com.claro.red.gestion.addserver.common.exceptions.BaseException;
import pe.com.claro.red.gestion.addserver.common.exceptions.DBException;
import pe.com.claro.red.gestion.addserver.common.exceptions.IDFException;
import pe.com.claro.red.gestion.addserver.common.property.PropertiesExterno;
import pe.com.claro.red.gestion.addserver.common.util.ClaroUtil;
import pe.com.claro.red.gestion.addserver.domain.bean.RecibeTripletaSQLResponse;
import pe.com.claro.red.gestion.addserver.domain.bean.RegistraErroresRequest;
import pe.com.claro.red.gestion.addserver.domain.repository.EirDao;

@Component
public class RecibeTripletaService {

  private static final Logger logger = LoggerFactory.getLogger(RecibeTripletaService.class);

  @Autowired
  private EirDao eirDao;

  @Autowired
  private PropertiesExterno prop;

  String idtx = "";
  String tripleta = "";

  public RecibeTripletaResponseType recibirTripleta(String msgIdTx, String fechaRegistro, String idTransaccion,
      String imsi, String msisdn, String imei) {

    idtx = idTransaccion;
    String[] arrayInput = { imsi, msisdn, imei };
    tripleta = Arrays.toString(arrayInput);

    RecibeTripletaResponseType response = new RecibeTripletaResponseType();

    ResponseData respData = new ResponseData();
    respData.setTripleta(tripleta);
    response.setResponseData(respData);
    response.setListaOpcional(new ArrayList<>());
    ResponseStatus respStatus = new ResponseStatus();
    respStatus.setIdTransaccion(idTransaccion);

    try {

      RecibeTripletaRequestType act1 = completarRequest(msgIdTx, fechaRegistro, imsi, msisdn, imei);

      ResponseBean act2 = validarParametros(msgIdTx, act1);

      if (Constantes.TEXTO_CERO.equalsIgnoreCase(act2.getCodigo())) {

        ResponseBean act3 = insertaIntermedia(msgIdTx, act1);

        if (!Constantes.TEXTO_CERO.equalsIgnoreCase(act3.getCodigo())) {
          procesaErrores(msgIdTx, act3.getCodigo(), act3.getMensaje());
        }

        respStatus.setCodigoRespuesta(act3.getCodigo());
        respStatus.setMensajeRespuesta(act3.getMensaje());

      } else {
        respStatus.setCodigoRespuesta(act2.getCodigo());
        respStatus.setMensajeRespuesta(act2.getMensaje());
      }

    } catch (BaseException be) {
      logger.debug("BaseException" + be);
      respStatus.setCodigoRespuesta(be.getCode());
      respStatus.setMensajeRespuesta(be.getMessage());

    } catch (Exception e) {
      logger.debug("BaseException" + e);
      respStatus.setCodigoRespuesta(prop.codigoIDT4);
      respStatus.setMensajeRespuesta(prop.mensajeIDT4);

    } finally {
      response.setResponseStatus(respStatus);
    }

    return response;
  }

  private RecibeTripletaRequestType completarRequest(String msgIdTx, String fecha, String imsi, String msisdn,
      String imei) {

    RecibeTripletaRequestType response = new RecibeTripletaRequestType();
    Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().serializeNulls().create();

    try {

      inicioActividad(msgIdTx, Constantes.ACTIVIDAD1);

      response.setFechaRegistro(fecha);
      response.setImei(imei);
      response.setImsi(imsi);
      response.setMsisdn(msisdn);
      response.setListaOpcional(new ArrayList<>());

      logger.info(Constantes.LOG_PARAM3, msgIdTx, Constantes.PARAMETROSBODY, gson.toJson(response));

    } finally {
      finActividad(msgIdTx, Constantes.ACTIVIDAD1);
    }

    return response;
  }

  private ResponseBean validarParametros(String msjIdTx, RecibeTripletaRequestType request) {
    ResponseBean response = new ResponseBean();

    try {
      inicioActividad(msjIdTx, Constantes.ACTIVIDAD2);

      Long var1 = Long.parseLong(request.getImsi());
      Long var2 = Long.parseLong(request.getMsisdn());
      Long var3 = Long.parseLong(request.getImei());

      if (var1 < 0 || var2 < 0 || var3 < 0) {
        throw new IDFException(prop.codigoIDF1, prop.mensajeIDF1);
      }

      response.setCodigo(prop.codigoIDF0);
      response.setMensaje(prop.mensajeIDF0);
      logger.debug(Constantes.LOG_PARAM2, msjIdTx, response.getMensaje());

    } catch (IDFException idfe) {
      logger.debug("[IDFException]", idfe);
      logger.error(Constantes.LOG_PARAM3, msjIdTx, Constantes.ERROR, idfe.getMessage());
      response.setCodigo(idfe.getCode());
      response.setMensaje(idfe.getMessage());

    } catch (Exception e) {
      logger.debug("[Exception]", e);
      String emsg = Constantes.TEXTO_VACIO + e.getMessage();
      logger.error(Constantes.LOG_PARAM3, msjIdTx, Constantes.ERROR, emsg.equals("null") ? prop.mensajeIDF1 : emsg);
      response.setCodigo(prop.codigoIDF1);
      response.setMensaje(prop.mensajeIDF1);

    } finally {

      finActividad(msjIdTx, Constantes.ACTIVIDAD2);
    }
    return response;

  }

  private ResponseBean insertaIntermedia(String msjIdTx, RecibeTripletaRequestType request) {

    ResponseBean response = new ResponseBean();

    try {

      inicioActividad(msjIdTx, Constantes.ACTIVIDAD3);

      RecibeTripletaSQLResponse respIntermedia = eirDao.registraIntermedia(msjIdTx, request);

      if (!respIntermedia.getCodRpta().equalsIgnoreCase(Constantes.TEXTO_CERO)) {
        throw new IDFException(prop.codigoIDF2, prop.mensajeIDF2);
      }

      response.setCodigo(respIntermedia.getCodRpta());
      response.setMensaje(respIntermedia.getMsjRpta());

    } catch (DBException dbe3) {
      logger.debug("DBException", dbe3);
      response.setCodigo(dbe3.getCode());
      response.setMensaje(dbe3.getMessage());

    } catch (IDFException idfe3) {
      logger.debug("IDFException", idfe3);
      response.setCodigo(idfe3.getCode());
      response.setMensaje(idfe3.getMessage());

    } finally {

      finActividad(msjIdTx, Constantes.ACTIVIDAD3);
    }

    return response;

  }

  private void procesaErrores(String msjTx, String codError, String msgError) throws DBException {

    try {
      inicioActividad(msjTx, Constantes.ACTIVIDAD4);

      RegistraErroresRequest req = new RegistraErroresRequest();

      req.setIdtx(idtx);
      req.setProceso(Constantes.NOMBRERECURSO);
      req.setDescripcion(tripleta + Constantes.PUNTO_COMA + msgError);
      req.setCodigo(codError);
      req.setFecha(ClaroUtil.dateAString(new Date(), Constantes.FORMATOFECHAHORA));

      RecibeTripletaSQLResponse respError = eirDao.registraErrores(msjTx, req);

      if (respError.getCodRpta().equalsIgnoreCase(Constantes.TEXTO_CERO)) {
        logger.error(Constantes.LOG_PARAM3, msjTx, Constantes.ERROR, "Error Registrado");
      } else {
        logger.error(Constantes.LOG_PARAM3, msjTx, Constantes.ERROR, "Error NO Registrado");
      }

    } catch (DBException dbe4) {
      logger.debug("DBException", dbe4);
      logger.error(Constantes.LOG_PARAM3, msjTx, Constantes.ERROR, "[DBException] Error NO Registrado");
      throw new DBException(dbe4.getCode(), dbe4.getMessage());

    } finally {

      finActividad(msjTx, Constantes.ACTIVIDAD4);
    }

  }

  private void inicioActividad(String menTran, String actividad) {
    logger.debug("{}{}", menTran, Constantes.SEPARADOR);
    logger.debug("{}{}{}{}", menTran, Constantes.INICIO_ACTIVIDAD, actividad, Constantes.SEPARADOR_ACTIVIDAD);
    logger.debug("{}{}", menTran, Constantes.SEPARADOR);
  }

  private void finActividad(String menTran, String actividad) {
    logger.debug("{}{}", menTran, Constantes.SEPARADOR);
    logger.debug("{}{}{}{}", menTran, Constantes.FIN_ACTIVIDAD, actividad, Constantes.SEPARADOR_ACTIVIDAD);
    logger.debug("{}{}", menTran, Constantes.SEPARADOR);
  }
}
