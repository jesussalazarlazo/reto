package pe.com.claro.red.gestion.addserver.common.property;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PropertiesExterno {

  @Value("${ruta.archivo.log}")
  public String rutaLog;
  @Value("${ruta.properties.externo}")
  public String rutaProperties;
  @Value("${db.eirdb.jndi}")
  public String eirdbJndi;

  // BASE DE DATOS EIRDB
  @Value("${db.eirdb.nombre}")
  public String dbNombre;
  @Value("${db.eirdb.owner}")
  public String dbOwner;
  @Value("${db.eirdb.pkg.addserver}")
  public String dbPackageAddServer;
  @Value("${db.eirdb.sp.registra.intermedia}")
  public String spRegistraInt;
  @Value("${db.eirdb.sp.registra.intermedia.timeout.conexion}")
  public int spRegistraInterTimeoutConexion;
  @Value("${db.eirdb.sp.registra.intermedia.timeout.ejecucion}")
  public int spRegistraInterTimeoutEjecucion;
  @Value("${db.eirdb.sp.registra.errores}")
  public String spRegistraError;
  @Value("${db.eirdb.sp.registra.errores.timeout.conexion}")
  public int spRegistraErrorTimeoutConexion;
  @Value("${db.eirdb.sp.registra.errores.timeout.ejecucion}")
  public int spRegistraErrorTimeoutEjecucion;

  // IDF
  @Value("${gestion.addserver.codigo.idf}")
  public String codigoIDF0;
  @Value("${gestion.addserver.mensaje.idf}")
  public String mensajeIDF0;
  @Value("${gestion.addserver.codigo.idf1}")
  public String codigoIDF1;
  @Value("${gestion.addserver.mensaje.idf1}")
  public String mensajeIDF1;
  @Value("${gestion.addserver.codigo.idf2}")
  public String codigoIDF2;
  @Value("${gestion.addserver.mensaje.idf2}")
  public String mensajeIDF2;

  // IDT SP
  @Value("${gestion.addserver.sp.codigo.idt1}")
  public String codigoIDT1;
  @Value("${gestion.addserver.sp.mensaje.idt1}")
  public String mensajeIDT1;
  @Value("${gestion.addserver.sp.codigo.idt2}")
  public String codigoIDT2;
  @Value("${gestion.addserver.sp.mensaje.idt2}")
  public String mensajeIDT2;
  @Value("${gestion.addserver.sp.codigo.idt3}")
  public String codigoIDT3;
  @Value("${gestion.addserver.sp.mensaje.idt3}")
  public String mensajeIDT3;
  @Value("${gestion.addserver.codigo.idt4}")
  public String codigoIDT4;
  @Value("${gestion.addserver.mensaje.idt4}")
  public String mensajeIDT4;

}
