package pe.com.claro.red.gestion.addserver.canonical.type;

import lombok.Data;

@Data
public class ResponseData {

  private String tripleta;

}
