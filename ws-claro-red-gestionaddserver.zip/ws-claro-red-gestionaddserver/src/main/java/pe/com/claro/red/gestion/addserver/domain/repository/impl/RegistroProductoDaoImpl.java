package pe.com.claro.red.gestion.addserver.domain.repository.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import pe.com.claro.red.gestion.addserver.canonical.request.RegistraProductoRequest;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;
import pe.com.claro.red.gestion.addserver.common.exceptions.DBException;
import pe.com.claro.red.gestion.addserver.common.property.PropertiesExterno;
import pe.com.claro.red.gestion.addserver.common.util.ClaroUtil;
import pe.com.claro.red.gestion.addserver.domain.bean.RecibeTripletaSQLResponse;
import pe.com.claro.red.gestion.addserver.domain.bean.RegistraProductoBeanResponse;
import pe.com.claro.red.gestion.addserver.domain.repository.RegistroProductoDao;

public class RegistroProductoDaoImpl implements RegistroProductoDao {
	
	private static final Logger logger = LoggerFactory.getLogger(EirDaoImpl.class);

	  @Autowired
	  private PropertiesExterno prop;

	@SuppressWarnings("unchecked")
	@Override
	public RegistraProductoBeanResponse registaProducto (String msgIdtx, RegistraProductoRequest request)
			throws DBException {
		  long tiempoInicio = System.currentTimeMillis();
		  Map<String, Object> resultMap = null;
		  RegistraProductoBeanResponse response = new RegistraProductoBeanResponse();

		    String jndi = prop.eirdbJndi;
		    int timeoutConexion = prop.spRegistraInterTimeoutConexion;
		    int timeoutEjecucion = prop.spRegistraInterTimeoutEjecucion;
		    String bd = prop.dbNombre;
		    String owner = prop.dbOwner;
		    String procedure = prop.dbPackageAddServer + Constantes.PUNTO + prop.spRegistraInt;
		    String procedureOM = owner + Constantes.PUNTO + procedure;
		    Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().serializeNulls().create();
		    Connection connection = null;
		    CallableStatement call = null;

		    try {
		      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_NOMBREBD, bd);
		      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_OWNER, owner);
		      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_PROCEDURE, procedureOM);
		      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_JNDI, jndi);
		      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.PARAMETROSENTRADA, gson.toJson(request));

		      String callProcedure = String.format(Constantes.PARAMETRO_CALL, procedureOM, Constantes.SP_INPUT6);
		      connection = ClaroUtil.getConnection(msgIdtx, jndi, timeoutConexion);
		      call = connection.prepareCall(callProcedure);
		      call.setQueryTimeout(timeoutEjecucion);

		      call.setString("PI_IDPRODUCTO", request.getIdProducto());
		      call.setString("PI_NOMBRE", request.getNombreProducto());
		      call.setString("PI_FECHA_REGISTRO", request.getFechaRegistro());
		      call.setLong("CURSOR_OUT", java.sql.Types.REF_CURSOR);
		      call.registerOutParameter("PO_CODRPTA", java.sql.Types.VARCHAR);
		      call.registerOutParameter("PO_MSJRPTA", java.sql.Types.VARCHAR);
		      call.execute();

		      response.setCodigoRespuesta(call.getString("PO_CODRPTA"));
		      response.setMensajeRespuesta(call.getString("PO_MSJRPTA"));
		      response.setCursorOut(null);
				//response.setCursorOut((List<CursorOut>) resultMap.get(Constantes.PUNTO);
		    	        
		      //response.setCursorOut(new ArrayList<>());

		      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.PARAMETROSSALIDA, gson.toJson(response));

		    } catch (Exception ex) {
		      logger.error(msgIdtx, ex);
		      errorGenerico(ex, procedureOM, bd, timeoutEjecucion);

		    } finally {
		      ClaroUtil.connectionClose(null, call, connection, msgIdtx);
		      long tiempoProceso = System.currentTimeMillis() - tiempoInicio;
		      logger.debug(Constantes.LOG_PARAM2, msgIdtx, String.format(Constantes.TIEMPOTOTALPROCESO, tiempoProceso));

		    }

		    return response;
		  }
	
	
	  private void errorGenerico(Exception ex, String sp, String bd, int timeoutEjecucion) throws DBException {

		    String error = ex + Constantes.TEXTO_VACIO;
		    String codError;
		    String msjError;

		    if (error.contains(SQLTimeoutException.class.getName())) {
		      codError = prop.codigoIDT1;
		      msjError = String.format(prop.mensajeIDT1, timeoutEjecucion, prop.rutaProperties, bd,
		          sp + Constantes.GUION + ex.getMessage());

		    } else if (error.contains(SQLException.class.getName())) {
		      codError = prop.codigoIDT2;
		      msjError = String.format(prop.mensajeIDT2, bd, sp + Constantes.GUION + ex.getMessage());

		    } else {
		      codError = prop.codigoIDT3;
		      msjError = String.format(prop.mensajeIDT3, prop.rutaLog, bd, sp + Constantes.GUION + ex.getMessage());
		    }

		    throw new DBException(codError, msjError, ex);
		  }



}
