package pe.com.claro.red.gestion.addserver.domain.repository;

import pe.com.claro.red.gestion.addserver.canonical.request.RecibeTripletaRequestType;

import pe.com.claro.red.gestion.addserver.common.exceptions.DBException;
import pe.com.claro.red.gestion.addserver.domain.bean.RecibeTripletaSQLResponse;
import pe.com.claro.red.gestion.addserver.domain.bean.RegistraErroresRequest;


public interface EirDao {

  public RecibeTripletaSQLResponse registraIntermedia(String msgtx, RecibeTripletaRequestType request)
      throws DBException;

  public RecibeTripletaSQLResponse registraErrores(String msgIdtx, RegistraErroresRequest request) 
		  throws DBException;
  

}
