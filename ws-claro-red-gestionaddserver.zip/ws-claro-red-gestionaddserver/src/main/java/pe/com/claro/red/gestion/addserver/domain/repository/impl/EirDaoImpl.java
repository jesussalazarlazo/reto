package pe.com.claro.red.gestion.addserver.domain.repository.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import pe.com.claro.red.gestion.addserver.canonical.request.RecibeTripletaRequestType;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;
import pe.com.claro.red.gestion.addserver.common.exceptions.DBException;
import pe.com.claro.red.gestion.addserver.common.property.PropertiesExterno;
import pe.com.claro.red.gestion.addserver.common.util.ClaroUtil;

import pe.com.claro.red.gestion.addserver.domain.bean.RecibeTripletaSQLResponse;
import pe.com.claro.red.gestion.addserver.domain.bean.RegistraErroresRequest;
import pe.com.claro.red.gestion.addserver.domain.repository.EirDao;

@Repository
public class EirDaoImpl implements EirDao {

  private static final Logger logger = LoggerFactory.getLogger(EirDaoImpl.class);

  @Autowired
  private PropertiesExterno prop;

  @Override
  public RecibeTripletaSQLResponse registraIntermedia(String msgIdtx, RecibeTripletaRequestType request)
      throws DBException {

    long tiempoInicio = System.currentTimeMillis();

    RecibeTripletaSQLResponse response = new RecibeTripletaSQLResponse();

    String jndi = prop.eirdbJndi;
    int timeoutConexion = prop.spRegistraInterTimeoutConexion;
    int timeoutEjecucion = prop.spRegistraInterTimeoutEjecucion;
    String bd = prop.dbNombre;
    String owner = prop.dbOwner;
    String procedure = prop.dbPackageAddServer + Constantes.PUNTO + prop.spRegistraInt;
    String procedureOM = owner + Constantes.PUNTO + procedure;
    Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().serializeNulls().create();
    Connection connection = null;
    CallableStatement call = null;

    try {
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_NOMBREBD, bd);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_OWNER, owner);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_PROCEDURE, procedureOM);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_JNDI, jndi);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.PARAMETROSENTRADA, gson.toJson(request));

      String callProcedure = String.format(Constantes.PARAMETRO_CALL, procedureOM, Constantes.SP_INPUT6);
      connection = ClaroUtil.getConnection(msgIdtx, jndi, timeoutConexion);
      call = connection.prepareCall(callProcedure);
      call.setQueryTimeout(timeoutEjecucion);

      call.setString("PI_FECHA_REGISTRO", request.getFechaRegistro());
      call.setString("PI_IMSI", request.getImsi());
      call.setString("PI_MSISDN", request.getMsisdn());
      call.setString("PI_IMEI", request.getImei());
      call.registerOutParameter("PO_CODRPTA", java.sql.Types.VARCHAR);
      call.registerOutParameter("PO_MSJRPTA", java.sql.Types.VARCHAR);
      call.execute();

      response.setCodRpta(call.getString("PO_CODRPTA"));
      response.setMsjRpta(call.getString("PO_MSJRPTA"));

      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.PARAMETROSSALIDA, gson.toJson(response));

    } catch (Exception ex) {
      logger.error(msgIdtx, ex);
      errorGenerico(ex, procedureOM, bd, timeoutEjecucion);

    } finally {
      ClaroUtil.connectionClose(null, call, connection, msgIdtx);
      long tiempoProceso = System.currentTimeMillis() - tiempoInicio;
      logger.debug(Constantes.LOG_PARAM2, msgIdtx, String.format(Constantes.TIEMPOTOTALPROCESO, tiempoProceso));

    }

    return response;
  }
  
  

  @Override
  public RecibeTripletaSQLResponse registraErrores(String msgIdtx, RegistraErroresRequest request) throws DBException {

    long tiempoInicio = System.currentTimeMillis();

    RecibeTripletaSQLResponse response = new RecibeTripletaSQLResponse();

    String jndi = prop.eirdbJndi;
    int timeoutConexion = prop.spRegistraErrorTimeoutConexion;
    int timeoutEjecucion = prop.spRegistraErrorTimeoutEjecucion;
    String bd = prop.dbNombre;
    String owner = prop.dbOwner;
    String procedure = prop.dbPackageAddServer + Constantes.PUNTO + prop.spRegistraError;
    String procedureOM = owner + Constantes.PUNTO + procedure;
    Connection connection = null;
    CallableStatement call = null;
    Gson gson = new GsonBuilder().serializeSpecialFloatingPointValues().serializeNulls().create();

    try {
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_NOMBREBD, bd);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_OWNER, owner);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_PROCEDURE, procedureOM);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.SP_JNDI, jndi);
      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.PARAMETROSENTRADA, gson.toJson(request));

      String callProcedure = String.format(Constantes.PARAMETRO_CALL, procedureOM, Constantes.SP_INPUT7);
      connection = ClaroUtil.getConnection(msgIdtx, jndi, timeoutConexion);
      call = connection.prepareCall(callProcedure);
      call.setQueryTimeout(timeoutEjecucion);

      call.setString(1, request.getIdtx());
      call.setString(2, request.getProceso());
      call.setString(3, request.getDescripcion());
      call.setString(4, request.getCodigo());
      call.setString(5, request.getFecha());
      call.registerOutParameter(6, java.sql.Types.VARCHAR);
      call.registerOutParameter(7, java.sql.Types.VARCHAR);
      call.execute();

      response.setCodRpta(call.getString(6));
      response.setMsjRpta(call.getString(7));

      logger.debug(Constantes.LOG_PARAM3, msgIdtx, Constantes.PARAMETROSSALIDA, gson.toJson(response));

    } catch (Exception ex) {
      logger.error(msgIdtx, ex);
      errorGenerico(ex, procedureOM, bd, timeoutEjecucion);

    } finally {
      ClaroUtil.connectionClose(null, call, connection, msgIdtx);
      long tiempoProceso = System.currentTimeMillis() - tiempoInicio;
      logger.debug(Constantes.LOG_PARAM2, msgIdtx, String.format(Constantes.TIEMPOTOTALPROCESO, tiempoProceso));

    }

    return response;
  }

  private void errorGenerico(Exception ex, String sp, String bd, int timeoutEjecucion) throws DBException {

    String error = ex + Constantes.TEXTO_VACIO;
    String codError;
    String msjError;

    if (error.contains(SQLTimeoutException.class.getName())) {
      codError = prop.codigoIDT1;
      msjError = String.format(prop.mensajeIDT1, timeoutEjecucion, prop.rutaProperties, bd,
          sp + Constantes.GUION + ex.getMessage());

    } else if (error.contains(SQLException.class.getName())) {
      codError = prop.codigoIDT2;
      msjError = String.format(prop.mensajeIDT2, bd, sp + Constantes.GUION + ex.getMessage());

    } else {
      codError = prop.codigoIDT3;
      msjError = String.format(prop.mensajeIDT3, prop.rutaLog, bd, sp + Constantes.GUION + ex.getMessage());
    }

    throw new DBException(codError, msjError, ex);
  }

}
