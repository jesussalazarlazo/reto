package pe.com.claro.red.gestion.addserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({ "pe.com.claro.red.gestion.addserver" })
public class ClaroRedGestionAddServerApp {

  public static void main(String[] args) {
    SpringApplication.run(ClaroRedGestionAddServerApp.class, args);
  }

}
