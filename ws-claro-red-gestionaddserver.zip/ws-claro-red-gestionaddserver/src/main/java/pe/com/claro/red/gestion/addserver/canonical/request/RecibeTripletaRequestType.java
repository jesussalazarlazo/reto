package pe.com.claro.red.gestion.addserver.canonical.request;

import java.util.List;

import lombok.Data;
import pe.com.claro.red.gestion.addserver.canonical.type.ListaOpcional;

@Data
public class RecibeTripletaRequestType {

  private String fechaRegistro;
  private String imsi;
  private String msisdn;
  private String imei;
  private List<ListaOpcional> listaOpcional;

}
