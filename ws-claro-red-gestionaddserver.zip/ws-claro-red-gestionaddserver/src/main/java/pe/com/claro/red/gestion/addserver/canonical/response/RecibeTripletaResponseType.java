package pe.com.claro.red.gestion.addserver.canonical.response;

import java.util.List;

import lombok.Data;
import pe.com.claro.red.gestion.addserver.canonical.type.ListaOpcional;
import pe.com.claro.red.gestion.addserver.canonical.type.ResponseData;
import pe.com.claro.red.gestion.addserver.canonical.type.ResponseStatus;

@Data
public class RecibeTripletaResponseType {

  private ResponseStatus responseStatus;
  private ResponseData responseData;
  private List<ListaOpcional> listaOpcional;

}
