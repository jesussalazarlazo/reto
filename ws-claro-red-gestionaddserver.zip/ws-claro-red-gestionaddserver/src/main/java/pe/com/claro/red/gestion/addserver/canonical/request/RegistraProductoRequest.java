package pe.com.claro.red.gestion.addserver.canonical.request;

import lombok.Data;

@Data
public class RegistraProductoRequest {

    private String nombreProducto;
    private String idProducto;
    private String fechaRegistro;

}
