package pe.com.claro.red.gestion.addserver.canonical.response;

import java.util.List;

import lombok.Data;

@Data
public class RegistraProductoResponse {

	private List<ProductList> products;
    private ResponseStatus responseStatus;
}

@Data
class ProductList {
    private String nombreProducto;
    private String idProducto;
    private String fechaRegistro;
}

@Data
class ResponseStatus {
    private int codigoRespuesta;
    private String mensajeRespuesta;
}