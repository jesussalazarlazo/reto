package pe.com.claro.red.gestion.addserver.canonical.response;

import lombok.Data;

@Data
public class ResponseBean {
  private String codigo;
  private String mensaje;
}
