package pe.com.claro.red.gestion.addserver.domain.bean;

import lombok.Data;

@Data
public class RegistraErroresRequest {
  private String idtx;
  private String proceso;
  private String descripcion;
  private String codigo;
  private String fecha;
}
