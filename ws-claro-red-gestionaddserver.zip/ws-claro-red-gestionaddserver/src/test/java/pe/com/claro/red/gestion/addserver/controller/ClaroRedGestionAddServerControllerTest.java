package pe.com.claro.red.gestion.addserver.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import com.fasterxml.jackson.core.JsonProcessingException;

import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import pe.com.claro.red.gestion.addserver.canonical.response.RecibeTripletaResponse;
import pe.com.claro.red.gestion.addserver.canonical.response.RecibeTripletaResponseType;
import pe.com.claro.red.gestion.addserver.canonical.type.ResponseData;
import pe.com.claro.red.gestion.addserver.canonical.type.ResponseStatus;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;
import pe.com.claro.red.gestion.addserver.common.exceptions.IDFException;
import pe.com.claro.red.gestion.addserver.common.property.PropertiesExterno;
import pe.com.claro.red.gestion.addserver.domain.repository.EirDao;
import pe.com.claro.red.gestion.addserver.domain.service.RecibeTripletaService;

@RunWith(MockitoJUnitRunner.class)
public class ClaroRedGestionAddServerControllerTest {

  @Mock
  private PropertiesExterno prop;

  @Mock
  private RecibeTripletaService service;
  @Mock
  private EirDao eirdb;

  @InjectMocks
  private ClaroRedGestionAddServerController controller;

  String idTransaccion = "";
  String userId = "";
  String msgid = "";
  String timestamp = "";
  String accept = "";
  String aplicacion = "";
  String IMSI = "IMSI";
  String MSISDN = "MSISDN";
  String DEVICEID = "deviceID";

  @Test
  public void testRecibeTriplSuccessIDF0() throws JsonProcessingException, IDFException {

    Mockito.when(service.recibirTripleta(ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(String.class))).thenReturn(getResponseObteIDF0());

    RecibeTripletaResponse recibeTripletaRes = controller.recibirTripleta(IMSI, MSISDN, DEVICEID);
    assertEquals(Constantes.TEXTO_CERO,
        recibeTripletaRes.getTripletaResponse().getResponseStatus().getCodigoRespuesta());

  }

  @Test
  public void testRecibeTriplSuccessIDT1() throws JsonProcessingException, IDFException {

    Mockito.when(service.recibirTripleta(ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(String.class))).thenReturn(getResponseObteIDT1());

    RecibeTripletaResponse recibeTripletaRes = controller.recibirTripleta(IMSI, MSISDN, DEVICEID);
    assertEquals(Constantes.MTRES, recibeTripletaRes.getTripletaResponse().getResponseStatus().getCodigoRespuesta());

  }

  private RecibeTripletaResponseType getResponseObteIDT1() {

    RecibeTripletaResponseType recibeTripletaRes = new RecibeTripletaResponseType();
    ResponseStatus respStatus = new ResponseStatus();
    respStatus.setCodigoRespuesta("-3");
    recibeTripletaRes.setResponseStatus(respStatus);

    return recibeTripletaRes;
  }

  private RecibeTripletaResponseType getResponseObteIDF1() {

    RecibeTripletaResponseType recibeTripletaRes = new RecibeTripletaResponseType();
    ResponseStatus respStatus = new ResponseStatus();
    respStatus.setCodigoRespuesta("1");
    recibeTripletaRes.setResponseStatus(respStatus);

    return recibeTripletaRes;
  }

  private RecibeTripletaResponseType getResponseObteIDF0() {

    RecibeTripletaResponseType recibeTripletaRes = new RecibeTripletaResponseType();
    ResponseStatus respStatus = new ResponseStatus();
    ResponseData respData = new ResponseData();
    respData.setTripleta("");
    respStatus.setCodigoRespuesta("0");
    respStatus.setMensajeRespuesta("Operacion Exitosa");
    respStatus.setIdTransaccion("12113");
    recibeTripletaRes.setResponseStatus(respStatus);
    recibeTripletaRes.setResponseData(respData);

    return recibeTripletaRes;
  }

  @Test
  public void testRecibeTriplSuccessIDTT() throws JsonProcessingException, IDFException {

    Mockito.when(service.recibirTripleta(ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class), ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(String.class))).thenReturn(getResponseObteIDF1());

    RecibeTripletaResponse recibeTripletaRes = controller.recibirTripleta(IMSI, MSISDN, DEVICEID);
    assertEquals(Constantes.MUNO, recibeTripletaRes.getTripletaResponse().getResponseStatus().getCodigoRespuesta());

  }

  @Before
  public void init() {

    prop.eirdbJndi = "pe.com.claro.jdbc.datasources.noXA.eirdb";
    prop.dbNombre = "EIRDB";
    prop.dbOwner = "EIRADD";
    prop.dbPackageAddServer = "PKG_GESTION_ADDSERVER";
    prop.spRegistraInt = "EASI_INS_INTERMEDIA";
    prop.spRegistraInterTimeoutConexion = 1;
    prop.spRegistraInterTimeoutEjecucion = 1;
    prop.spRegistraError = "EASI_INS_ERRORES";
    prop.spRegistraErrorTimeoutConexion = 1;
    prop.spRegistraErrorTimeoutEjecucion = 1;

    prop.codigoIDF0 = "0";
    prop.mensajeIDF0 = "Operación exitosa";
    prop.codigoIDF1 = "1";
    prop.mensajeIDF1 = "Tripleta incompleta o nulo.";
    prop.codigoIDF2 = "2";
    prop.mensajeIDF2 = "Error al insertar registro en la Tabla Intermedia.";

    prop.codigoIDT1 = "-1";
    prop.mensajeIDT1 = "Error de timeout, el tiempo configurado = %s segundos en el archivo properties (%s) se ha superado: %s - %s";
    prop.codigoIDT2 = "-2";
    prop.mensajeIDT2 = "Error de Disponibilidad, revisar privilegios del usuario USREIRADD sobre los objectos EIRDB: %s - %s";
    prop.codigoIDT3 = "-3";
    prop.mensajeIDT3 = "Error Generico, revisar Weblogic, objetos EIRDB, compilado (WAR), LOG (%s): %s - %s";
    prop.codigoIDT3 = "-4";
    prop.mensajeIDT3 = "Ocurrio un error durante el proceso";

  }

}
