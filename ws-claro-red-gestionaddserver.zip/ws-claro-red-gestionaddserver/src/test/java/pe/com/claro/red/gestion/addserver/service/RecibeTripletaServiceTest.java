package pe.com.claro.red.gestion.addserver.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import pe.com.claro.red.gestion.addserver.canonical.request.RecibeTripletaRequestType;
import pe.com.claro.red.gestion.addserver.common.constants.Constantes;
import pe.com.claro.red.gestion.addserver.common.exceptions.BaseException;
import pe.com.claro.red.gestion.addserver.common.exceptions.DBException;
import pe.com.claro.red.gestion.addserver.common.exceptions.IDFException;
import pe.com.claro.red.gestion.addserver.common.property.PropertiesExterno;
import pe.com.claro.red.gestion.addserver.domain.bean.RecibeTripletaSQLResponse;
import pe.com.claro.red.gestion.addserver.domain.bean.RegistraErroresRequest;
import pe.com.claro.red.gestion.addserver.domain.repository.EirDao;
import pe.com.claro.red.gestion.addserver.domain.service.RecibeTripletaService;

@RunWith(MockitoJUnitRunner.class)
public class RecibeTripletaServiceTest {

  @InjectMocks
  private RecibeTripletaService service;

  @Mock
  private PropertiesExterno prop;

  @Mock
  private EirDao eirdb;

  private String msjTx = "ClaroRedGestionAddServer - 20220602185657";
  String idTransaccion = "";
  String userId = "";
  String msgid = "564";
  String timestamp = "";
  String accept = "";
  String aplicacion = "";
  String imsi = "123";
  String msisdn = "342";
  String DEVICEID = "453";
  String fechaRegistro = "534";
  String imei = "34543";

  @Test
  public void testActuSuccessIDF0() throws Exception, DBException {

    Mockito.when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenReturn(getRecibirEirResponseIDF0());

    try {
      service.recibirTripleta(msjTx, fechaRegistro, idTransaccion, imsi, msisdn, imei);

    } catch (Exception e) {
      assertNotNull(e);
    }

  }

  @Test
  public void testActuSuccessIDF2() throws Exception, DBException {

    Mockito.when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
        ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenReturn(getRecibirEirResponseIDF2());

    try {
      service.recibirTripleta(msjTx, fechaRegistro, idTransaccion, imsi, msisdn, imei);

    } catch (Exception e) {
      assertNotNull(e);
    }

  }

  @Test
  public void testActuError2() throws BaseException {

    try {
      service.recibirTripleta(msjTx, fechaRegistro, idTransaccion, imsi, msisdn, imei);
    } catch (Exception e) {
      assertNotNull(e);
    }
  }

  @Test
  public void testActuError2DB() throws BaseException {

    try {
      Mockito.when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
          ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenThrow(new IllegalArgumentException());

      service.recibirTripleta(msjTx, fechaRegistro, idTransaccion, imsi, msisdn, imei);
    } catch (Exception e) {
      assertNotNull(e);
    }
  }

  private RecibeTripletaSQLResponse getRecibirEirResponseIDF0() {
    RecibeTripletaSQLResponse recibeRespo = new RecibeTripletaSQLResponse();
    recibeRespo.setCodRpta("0");
    // recibeRespo.setMsjRpta("operacion exitosa");
    assertNotNull(recibeRespo);
    return recibeRespo;
  }

  private RecibeTripletaSQLResponse getRecibirEirResponseIDF2() {
    RecibeTripletaSQLResponse recibeRespo = new RecibeTripletaSQLResponse();
    recibeRespo.setCodRpta("2");
    // recibeRespo.setMsjRpta("operacion exitosa");
    assertNotNull(recibeRespo);
    return recibeRespo;
  }

  public String code = "-1";
  public String piDepacSap = "35";
  public int piCantLinea = 3;

  public String message = "Error Interno";
  public Exception e = new Exception();
  public int status = 500;
  public String messageDeveloper = "HTTP 500 Internal Server Error";
  private BaseException dBException;
  public String descriptionError = "descripcioNErrror";
  public String status1 = "500";

  @Test
  public void BaseExceptionTest() {
    BaseException dbException = new BaseException(message);
    assertNotNull(dbException);
    dbException = new BaseException(code, message, e);
    assertNotNull(dbException);
    dbException = new BaseException(code, message);
    assertNotNull(dbException);
    dbException = new BaseException(code, descriptionError, message, e);
    assertNotNull(dbException);
    dbException.setDescriptionError(descriptionError);
    dbException.setException(e);
    dbException.getDescriptionError();
    dbException.getMessageDeveloper();
    dbException.getStatus();
    dbException = new BaseException(code, message, messageDeveloper, e, status);
    assertNotNull(dbException);
    dbException = new BaseException(message, e);
    assertNotNull(dbException);
    dbException = new BaseException(e);
    assertNotNull(dbException);
    dbException = new BaseException(messageDeveloper);
    dbException.setMessageDeveloper(messageDeveloper);
    assertNotNull(dbException);
    dbException = new BaseException(status1);
    dbException.setStatus(status);
    assertNotNull(dbException);

  }

  @Test
  public void dbExceptionTest() {
    DBException dbException = new DBException(message);
    assertNotNull(dbException);
    dbException = new DBException(code, message, e);
    assertNotNull(dbException);
    dbException = new DBException(code, message);
    assertNotNull(dbException);
    dbException = new DBException(code, descriptionError, message, e);
    assertNotNull(dbException);
    dbException = new DBException(code, message, messageDeveloper, e);
    assertNotNull(dbException);
    dbException = new DBException(message, e);
    assertNotNull(dbException);
    dbException = new DBException(e);
    assertNotNull(dbException);
    dbException = new DBException(code, message, messageDeveloper, e, status);
    assertNotNull(dbException);

  }

  @Test
  public void RecibeTripletaSQLResponseTest() {
    RecibeTripletaSQLResponse recibeRespon = new RecibeTripletaSQLResponse();
    assertNotNull(recibeRespon);
    recibeRespon.setCodRpta(code);
    recibeRespon.setMsjRpta(msjTx);
    ;

  }

  @Test
  public void BaseExceptionTest04() throws BaseException {
    Exception exception = new Exception();
    dBException = new BaseException("code", "mensaje", exception);

    Assert.assertEquals("code", dBException.getCode());
    Assert.assertEquals("mensaje", dBException.getMessage());
    Assert.assertEquals(exception, dBException.getException());

  }

  @Test
  public void idfExceptionTest() {
    IDFException baseException = new IDFException(message);
    assertNotNull(baseException);
    baseException = new IDFException(message, e);
    assertNotNull(baseException);
    baseException = new IDFException(code, message);
    assertNotNull(baseException);
    baseException = new IDFException(code, message);
    assertNotNull(baseException);

    assertNotNull(baseException);

  }

  @Before
  public void init() {

    prop.eirdbJndi = "pe.com.claro.jdbc.datasources.noXA.eirdb";
    prop.dbNombre = "EIRDB";
    prop.dbOwner = "EIRADD";
    prop.dbPackageAddServer = "PKG_GESTION_ADDSERVER";
    prop.spRegistraInt = "EASI_INS_INTERMEDIA";
    prop.spRegistraInterTimeoutConexion = 1;
    prop.spRegistraInterTimeoutEjecucion = 1;
    prop.spRegistraError = "EASI_INS_ERRORES";
    prop.spRegistraErrorTimeoutConexion = 1;
    prop.spRegistraErrorTimeoutEjecucion = 1;

    prop.codigoIDF0 = "0";
    prop.mensajeIDF0 = "Operación exitosa";
    prop.codigoIDF1 = "1";
    prop.mensajeIDF1 = "Tripleta incompleta o nulo.";
    prop.codigoIDF2 = "2";
    prop.mensajeIDF2 = "Error al insertar registro en la Tabla Intermedia.";

    prop.codigoIDT1 = "-1";
    prop.mensajeIDT1 = "Error de timeout, el tiempo configurado = %s segundos en el archivo properties (%s) se ha superado: %s - %s";
    prop.codigoIDT2 = "-2";
    prop.mensajeIDT2 = "Error de Disponibilidad, revisar privilegios del usuario USREIRADD sobre los objectos EIRDB: %s - %s";
    prop.codigoIDT3 = "-3";
    prop.mensajeIDT3 = "Error Generico, revisar Weblogic, objetos EIRDB, compilado (WAR), LOG (%s): %s - %s";
    prop.codigoIDT3 = "-4";
    prop.mensajeIDT3 = "Ocurrio un error durante el proceso";

  }

  @Test
  public void test001() {

    try {
      service.recibirTripleta(msjTx, fechaRegistro, idTransaccion, imsi, null, imei);
    } catch (Exception e) {
      assertNotNull(e);
    }
  }

  @Test
  public void test002() {

    try {
      service.recibirTripleta(msjTx, fechaRegistro, idTransaccion, imsi, "-1", imei);
    } catch (Exception e) {
      assertNotNull(e);
    }
  }

  @Test
  public void test003() {

    try {
      when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
          ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenThrow(DBException.class);
      service.recibirTripleta(msjTx, fechaRegistro, "123", "123", "123", "123");
    } catch (Exception e) {
      assertEquals("0", Constantes.TEXTO_CERO);
    }
  }

  @Test
  public void test004() {

    try {
      when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
          ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenReturn(getRecibirEirResponseIDF2());
      when(
          eirdb.registraErrores(ArgumentMatchers.any(String.class), ArgumentMatchers.any(RegistraErroresRequest.class)))
              .thenThrow(DBException.class);
      service.recibirTripleta(msjTx, fechaRegistro, "123", "123", "123", "123");
    } catch (Exception e) {
      assertEquals("0", Constantes.TEXTO_CERO);
    }
  }

  @Test
  public void test005() {

    try {
      when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
          ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenReturn(getRecibirEirResponseIDF2());
      when(
          eirdb.registraErrores(ArgumentMatchers.any(String.class), ArgumentMatchers.any(RegistraErroresRequest.class)))
              .thenReturn(getRecibirEirResponseIDF2());
      service.recibirTripleta(msjTx, fechaRegistro, "123", "123", "123", "123");
    } catch (Exception e) {
      assertEquals("0", Constantes.TEXTO_CERO);
    }
  }

  @Test
  public void test006() {

    try {
      when(eirdb.registraIntermedia(ArgumentMatchers.any(String.class),
          ArgumentMatchers.any(RecibeTripletaRequestType.class))).thenReturn(getRecibirEirResponseIDF2());
      when(
          eirdb.registraErrores(ArgumentMatchers.any(String.class), ArgumentMatchers.any(RegistraErroresRequest.class)))
              .thenReturn(getRecibirEirResponseIDF0());
      service.recibirTripleta(msjTx, fechaRegistro, "123", "123", "123", "123");
    } catch (Exception e) {
      assertEquals("0", Constantes.TEXTO_CERO);
    }
  }

}
